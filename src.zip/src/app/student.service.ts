import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  
  private apiUrl = 'http://localhost:8080/student'; // Replace with your Spring Boot backend URL

  constructor(private http: HttpClient) {}

   addStudent(student: any): Observable<any> {
    const addStudentUrl = `${this.apiUrl}/saveStudent`; // Replace with your API endpoint URL
    return this.http.post(addStudentUrl, student);
  }
  getStudentById(id: number) {
    const url = `${this.apiUrl}/getstudent/${id}`;
    return this.http.get(url);
  }

  getAllStudents(): Observable<any> {
    return this.http.get(`${this.apiUrl}/getallstudents`);
  }

  updateStudent(student: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/updatestudents`, student);
  }

  deleteStudent(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/deletestudent/${id}`);
  }
}
