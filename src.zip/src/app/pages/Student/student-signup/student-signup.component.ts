import { Component, OnInit } from '@angular/core';
import { StudentService } from 'src/app/student.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-student-signup',
  templateUrl: './student-signup.component.html',
  styleUrls: ['./student-signup.component.css']
})
export class StudentSignupComponent implements OnInit{

  ngOnInit(): void {
  }

  constructor(
    private studentService:StudentService,private router:Router
  ) {}

  user_records:any[]=[];

  public user={
    firstname:'',
    lastname:'',
    gender:'',
    studentemail:'',
    password:'',
    course:''

  };
  
  submitForm(){
    console.log(this.user)
    if(this.user.firstname=='' ||this.user.firstname==null)
    {
      alert('user is required');
     
    }

    this.studentService.addStudent(this.user).subscribe(
    (data:any) => {
      //success
      console.log(data);
      
         },
    (error: any) =>
    {
      console.log(error);
      alert('error');
     
    }
    );

    this.user_records=JSON.parse(localStorage.getItem('users')||'{}');
    if(this.user_records.some((v)=>{
      return v.studentemail==this.user.studentemail
    })){
      alert("Duplicate Data");
    }
    else{
      this.user_records.push(this.user)
      localStorage.setItem("users",JSON.stringify(this.user_records));
      alert("Hi"+" "+this.user.firstname+" "+"You are successfully registered");
    }
  }
    
  }
  

