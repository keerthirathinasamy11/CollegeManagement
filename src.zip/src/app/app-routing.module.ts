import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './pages/Student/login/login.component';
import { StudentSignupComponent } from './pages/Student/student-signup/student-signup.component';
import { StudentService } from './student.service';
import { StudentComponent } from './student/student.component';
import { AboutComponent } from './about/about.component';
import { AdminloginComponent } from './admin/adminlogin/adminlogin.component';
import { FacultyloginComponent } from './admin/facultylogin/facultylogin.component';
import { HomeComponent } from './home/home.component';
import { AdminDashboardComponent } from './admin/admin-dashboard/admin-dashboard.component';
import { FeesComponent } from './admin/fees/fees.component';
import { CoursesComponent } from './courses/courses.component';
import { AttendanceService } from './attendance.service';

const routes: Routes = [
  
  { path: '', component: HomeComponent },
  { path: 'student-signup', component: StudentSignupComponent },
  { path:'admin-dashboard', component :AdminDashboardComponent},
  { path: 'login', component: LoginComponent },
  { path: 'student', component: StudentComponent },
  { path: 'about', component: AboutComponent },
  { path: 'adminlogin', component: AdminloginComponent },
  { path: 'facultylogin', component: FacultyloginComponent },
  { path:'studentService', component:StudentService},
  { path :'attendance' ,component :AttendanceService},
  { path :'attendanceService',component :AttendanceService},
  { path :'fees',component:FeesComponent},
  { path :'courses',component:CoursesComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
