import { Component, OnInit } from '@angular/core';
import { OnSameUrlNavigation } from '@angular/router';
import { AttendanceService } from 'src/app/attendance.service';

@Component({
  selector: 'app-attendances',
  templateUrl: './attendances.component.html',
  styleUrls: ['./attendances.component.css']
})
export class AttendancesComponent implements OnInit {
  attendanceService: any;
  ngOnInit(): void {}

  attendanceAll:any;

  attendanceToUpdate ={
      studentid:"",
      studname:"",
      dept:"",
      year:"",
      month:"",
      totaldays:"",
      noOfdayspresent:"",
      noOfdaysabsent:""
  }

  constructor(private att:AttendanceService) {
      this.getAttendanceDetails();
  }
   
  public attendance ={
    studentid:'',
    studname:'',
    dept:'',
    year:'',
    month:'',
    totaldays:'',
    noOfdayspresent:'',
    noOfdaysabsent:'',
    
  };

  formSubmit() {
    this.attendanceService.addAttendance(this.attendance).subscribe(
    (data: any)=>{
      console.log(data);
      alert('success');
      this.getAttendanceDetails();
    },
    (error: any)=>{
      console.log(error);
      alert('wrong');
    }
    );
  }

  getAttendanceDetails(){
    this.attendanceService.getAttendance().subscribe((res: any)=>{
      console.log(res);
      this.attendanceAll= res;
    },
    (err: any)=>{
      console.log(err);
    }

    )
  }

  deleteAttendance(data:any){
    this.attendanceService.deleteAttendance(data.id).subscribe(
      (res: any)=>{
        console.log(res);
        this.getAttendanceDetails();
      },
      (err: any)=>{
        console.log(err);
      }
    )
  }
  
  edit(data:any){
    this.attendanceToUpdate=data;
  }

  updateAttendance(){
    this.attendanceService.updateAttendance(this.attendanceToUpdate).subscribe(
      (res: any)=>{
        console.log(res);
      },
      (err: any)=>{
        console.log(err);
      }
    )
  }
  

}
