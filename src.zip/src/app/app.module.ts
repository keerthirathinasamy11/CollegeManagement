import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StudentSignupComponent } from './pages/Student/student-signup/student-signup.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatCardModule} from '@angular/material/card';
import { MatToolbarModule } from '@angular/material/toolbar';

import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatOptionModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select'; 
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { HttpClientModule } from '@angular/common/http';
import {MatInputModule} from '@angular/material/input';
import { LoginComponent } from './pages/Student/login/login.component';
import { NavbarComponent } from './navbar/navbar.component';
import { StudentDashboardComponent } from './student-dashboard/student-dashboard.component';
import { StudentComponent } from './student/student.component';
import { MatButtonModule } from '@angular/material/button';
import { AboutComponent } from './about/about.component';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { AdminloginComponent } from './admin/adminlogin/adminlogin.component';
import { FacultyloginComponent } from './admin/facultylogin/facultylogin.component';
import { HomeComponent } from './home/home.component';
import { AdminDashboardComponent } from './admin/admin-dashboard/admin-dashboard.component';
import { FeesComponent } from './admin/fees/fees.component';
import { CoursesComponent } from './courses/courses.component';
import { AttendancesComponent } from './admin/faculty/attendances/attendances.component';

@NgModule({
  declarations: [
    AppComponent,
    StudentSignupComponent,
    LoginComponent,
    NavbarComponent,
    StudentDashboardComponent,
    StudentComponent,
    AboutComponent,
    AdminloginComponent,
    FacultyloginComponent,
    HomeComponent,
    AdminDashboardComponent,
    FeesComponent,
    CoursesComponent,
    AttendancesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatOptionModule,
    FormsModule,
    MatSelectModule,
    HttpClientModule,
    MatInputModule,
    MatFormFieldModule,
    MatSnackBarModule,
    MatButtonModule,
    MatCardModule,
    MatIconModule,
    MatToolbarModule,
    MatMenuModule

    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
